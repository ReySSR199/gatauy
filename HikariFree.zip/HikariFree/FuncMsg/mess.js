module.exports.mess = {
	baned: 'MAAF ANDA TELAH TERBANNED', 
	        wait: 'Ｌｏａｄｉｎｇ．．．',
			success: 'Ｓｕｃｃｅｓ．．．',
			wrongFormat: 'Format salah, coba liat lagi di menu',
			glimit: 'Limitmu Habis woy', 
			error: {
				api: 'Ups, terjadi kesalahan',
				stick: 'bukan sticker itu:v',
				Iv: 'Link tidak valid'
			},
			only: {
				group: 'Maaf! Command ini khusus untuk di dalam Group saja.',
				admin: 'Maaf! Command ini khusus untuk admin group saja.',
				premium: 'Kamu bukan user premium, kirim perintah *!buypremium* untuk membeli premium',
				owner: 'Maaf! Command ini khusus untuk Owner Bot saja.',
				Badmin: 'Maaf! Command ini khusus untuk Bot ketika jadi admin!!',
			}
		}